# machine_learning_assignment11
 1-nearest neighbor classification of time series using dynamic time warping (DTW) as the distance measure

python dtw_classify.py asl_training.txt asl_test.txt